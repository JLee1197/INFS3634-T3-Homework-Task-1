package com.example.clockapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

public class MainActivity extends AppCompatActivity {
    boolean buttonState = false;
    private ImageView refreshButton;
    boolean refreshButtonState = false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ConstraintLayout ClockFace = findViewById(R.id.sydney_clock);

        refreshButton = ClockFace.findViewById(R.id.refreshButtonImage);


        Thread thread = new Thread() {
            Date today = new Date();


            final DateFormat[] format = {new SimpleDateFormat("dd/MM/yyyy h:mm:ss a")};

            public void run() {


                try {
                    while (!isInterrupted()) {

                        Thread.sleep(1000);
                        runOnUiThread(new Runnable() {

                            public void run() {


                                TextView sydneyTime = (TextView) findViewById(R.id.sydneyClockTime);
                                format[0].setTimeZone(TimeZone.getTimeZone("Australia/NSW"));
                                String sydney = format[0].format(today);
                                String sydneyDateString = (sydney);
                                sydneyTime.setText(sydneyDateString);

                                TextView shanghaiTime = (TextView) findViewById(R.id.shanghaiClockTime);
                                format[0].setTimeZone(TimeZone.getTimeZone("Asia/Shanghai"));
                                String shanghai = format[0].format(today);
                                String shanghaiTimeString = (shanghai);
                                shanghaiTime.setText(shanghaiTimeString);

                                TextView newYorkTime = (TextView) findViewById(R.id.newYorkClockTime);
                                format[0].setTimeZone(TimeZone.getTimeZone("America/New_York"));
                                String newYork = format[0].format(today);
                                String newYorkTimeString = (newYork);
                                newYorkTime.setText(newYorkTimeString);

                                TextView parisTime = (TextView) findViewById(R.id.parisClockTime);
                                format[0].setTimeZone(TimeZone.getTimeZone("Europe/Paris"));
                                String paris = format[0].format(today);
                                String parisTimeString = (paris);
                                parisTime.setText(parisTimeString);

                                TextView LATime = (TextView) findViewById(R.id.LAClockTime);
                                format[0].setTimeZone(TimeZone.getTimeZone("America/Los_Angeles"));
                                String LA = format[0].format(today);
                                String LATimeString = (LA);
                                LATime.setText(LATimeString);

                                final Button am_pm_button = (Button) findViewById(R.id.am_pm_button);
                                if (buttonState) {
                                    am_pm_button.setText("24 Hour Time");
                                } else {
                                    am_pm_button.setText("12 Hour Time");
                                }

                                am_pm_button.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        if (buttonState == false) {

                                            am_pm_button.setText("24 Hour Time");
                                            format[0] = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");

                                            buttonState = true;

                                        } else if (buttonState == true) {
                                            am_pm_button.setText("12 Hour Time");

                                            format[0] = new SimpleDateFormat("dd/MM/yyyy h:mm:ss a");
                                            buttonState = false;

                                        }
                                    }
                                });
                            }
                        });
                    }
                } catch (InterruptedException e) {
                }
            }
        };
        thread.start();
        refreshButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "Refreshing", Toast.LENGTH_SHORT).show();
                if(!refreshButtonState) {
                    refreshButton.setImageResource(R.drawable.refresh2);
                    onRestart();
                } else {
                    refreshButton.setImageResource(R.drawable.refresh);
                    onRestart();
                }

                refreshButtonState = !refreshButtonState;
            }
        });
    }
    @Override
    protected void onRestart() {


        super.onRestart();
        Intent intent = new Intent(MainActivity.this, MainActivity.class);
        startActivity(intent);
        finish();

    }
}











